package com.example.collapse;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Реалистичное обрушение: если после разрушения блока часть конструкции теряет связь с землёй,
 * она падает. Высокие тонкие конструкции (столбы, деревья) заваливаются в сторону от игрока.
 * Дым при ударах зависит от высоты падения и массы блоков.
 */
public class CollapsePhysics implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("collapsephysics");

    // --- настройки ---
    static boolean enabled = true;
    static float smoke = 1.0f;
    static final int MAX_SCAN = 20000;        // сколько блоков максимум проверять
    static final int MAX_COLLAPSE = 5000;     // конструкции больше этого не рушатся
    static final int CHECKS_PER_TICK = 6;
    static final int SPAWN_PER_TICK = 700;    // блоков, превращаемых в падающие за тик
    static final int MAX_CELLS_PER_TICK = 300;

    enum Kind { NONE, STRUCT, ANCHOR }

    record Check(BlockPos pos, double px, double pz, boolean hasPlayer) {}

    static final class Debris {
        final FallingBlockEntity e; final int startY; final double mass; final BlockState state;
        Debris(FallingBlockEntity e, int startY, double mass, BlockState state) {
            this.e = e; this.startY = startY; this.mass = mass; this.state = state;
        }
    }

    static final class Job {
        List<BlockPos> blocks; int idx = 0;
        int minY, maxY, landY; boolean topple;
        double tx, tz, cx, cz;
    }

    static final class WS {
        final ArrayDeque<Check> checks = new ArrayDeque<>();
        final ArrayDeque<Job> jobs = new ArrayDeque<>();
        final List<Debris> debris = new ArrayList<>();
        final Map<Long, double[]> impacts = new HashMap<>();
    }

    private static final Map<ServerWorld, WS> STATES = new IdentityHashMap<>();

    private static WS state(ServerWorld w) { return STATES.computeIfAbsent(w, k -> new WS()); }

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, st, be) -> {
            if (!enabled || !(world instanceof ServerWorld sw)) return;
            state(sw).checks.add(new Check(pos.toImmutable(), player.getX(), player.getZ(), true));
        });

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            try {
                tick(world);
            } catch (Exception ex) {
                LOGGER.error("collapse tick failed", ex);
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("collapse")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> Text.literal("Collapse Physics: " + (enabled ? "включена" : "выключена")
                            + ", дым x" + smoke), false);
                    return 1;
                })
                .then(CommandManager.argument("enabled", BoolArgumentType.bool()).executes(ctx -> {
                    enabled = BoolArgumentType.getBool(ctx, "enabled");
                    ctx.getSource().sendFeedback(() -> Text.literal("Collapse Physics: " + (enabled ? "включена" : "выключена")), true);
                    return 1;
                }))
                .then(CommandManager.literal("smoke")
                    .then(CommandManager.argument("multiplier", FloatArgumentType.floatArg(0f, 5f)).executes(ctx -> {
                        smoke = FloatArgumentType.getFloat(ctx, "multiplier");
                        ctx.getSource().sendFeedback(() -> Text.literal("Множитель дыма: " + smoke), true);
                        return 1;
                    })))));
    }

    // ------------------------------------------------------------------ тик

    private static void tick(ServerWorld w) {
        WS st = STATES.get(w);
        if (st == null) return;

        int c = 0;
        while (!st.checks.isEmpty() && c++ < CHECKS_PER_TICK) {
            processCheck(w, st, st.checks.poll());
        }

        int budget = SPAWN_PER_TICK;
        while (budget > 0 && !st.jobs.isEmpty()) {
            Job j = st.jobs.peek();
            budget -= runJob(w, st, j, budget);
            if (j.idx >= j.blocks.size()) st.jobs.poll();
        }

        trackDebris(w, st);
        emitImpacts(w, st);
    }

    // ------------------------------------------------------- поиск оторванных частей

    private static boolean loaded(ServerWorld w, int x, int z) {
        return w.getChunkManager().getWorldChunk(x >> 4, z >> 4) != null;
    }

    private static boolean isTerrain(BlockState s) {
        if (s.isIn(BlockTags.DIRT) || s.isIn(BlockTags.SAND) || s.isIn(BlockTags.BASE_STONE_OVERWORLD)
                || s.isIn(BlockTags.BASE_STONE_NETHER) || s.isIn(BlockTags.TERRACOTTA)) return true;
        Block b = s.getBlock();
        return b == Blocks.GRAVEL || b == Blocks.CLAY || b == Blocks.END_STONE || b == Blocks.BEDROCK;
    }

    /** Земля — это широкий массив природного материала. Одиночный столб из камня землёй не считается. */
    private static boolean dense(ServerWorld w, BlockPos pos) {
        int c = 0;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int x = pos.getX() + dx, z = pos.getZ() + dz;
                if (!loaded(w, x, z)) { c++; continue; }
                if (isTerrain(w.getBlockState(new BlockPos(x, pos.getY(), z)))) c++;
            }
        }
        return c >= 12;
    }

    private static Kind classify(ServerWorld w, BlockPos pos) {
        if (pos.getY() < w.getBottomY()) return Kind.ANCHOR;
        if (pos.getY() >= w.getBottomY() + w.getHeight()) return Kind.NONE;
        if (!loaded(w, pos.getX(), pos.getZ())) return Kind.ANCHOR;
        BlockState s = w.getBlockState(pos);
        if (s.isAir()) return Kind.NONE;
        if (s.getBlock() == Blocks.BEDROCK) return Kind.ANCHOR;
        if (s.isIn(BlockTags.LEAVES)) return Kind.NONE;
        if (s.getCollisionShape(w, pos).isEmpty()) return Kind.NONE;
        if (isTerrain(s) && dense(w, pos)) return Kind.ANCHOR;
        return Kind.STRUCT;
    }

    /** @return null если конструкция опирается на землю (или слишком велика), иначе все её блоки */
    private static LongOpenHashSet scan(ServerWorld w, BlockPos start, LongOpenHashSet seen) {
        LongOpenHashSet vis = new LongOpenHashSet();
        LongArrayList stack = new LongArrayList();
        vis.add(start.asLong());
        stack.add(start.asLong());
        boolean supported = false;

        while (!stack.isEmpty() && !supported) {
            if (vis.size() > MAX_SCAN) { supported = true; break; }
            long cur = stack.removeLong(stack.size() - 1);
            BlockPos p = BlockPos.fromLong(cur);
            for (Direction d : Direction.values()) {
                BlockPos q = p.offset(d);
                long ql = q.asLong();
                if (vis.contains(ql)) continue;
                Kind k = classify(w, q);
                if (k == Kind.ANCHOR) { supported = true; break; }
                if (k == Kind.STRUCT) { vis.add(ql); stack.add(ql); }
            }
        }
        seen.addAll(vis);
        return supported ? null : vis;
    }

    private static void processCheck(ServerWorld w, WS st, Check c) {
        LongOpenHashSet seen = new LongOpenHashSet();
        for (Direction d : Direction.values()) {
            BlockPos n = c.pos().offset(d);
            if (seen.contains(n.asLong())) continue;
            if (classify(w, n) != Kind.STRUCT) continue;
            LongOpenHashSet comp = scan(w, n, seen);
            if (comp == null) continue;
            if (comp.size() > MAX_COLLAPSE) continue;
            st.jobs.add(makeJob(w, st, comp, c));
        }
    }

    // ------------------------------------------------------------- обрушение

    private static Job makeJob(ServerWorld w, WS st, LongOpenHashSet comp, Check c) {
        Job j = new Job();
        j.blocks = new ArrayList<>(comp.size());
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        LongIterator it = comp.iterator();
        while (it.hasNext()) {
            BlockPos p = BlockPos.fromLong(it.nextLong());
            j.blocks.add(p);
            minY = Math.min(minY, p.getY());
            maxY = Math.max(maxY, p.getY());
        }
        j.minY = minY;
        j.maxY = maxY;

        int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
        double sx = 0, sz = 0;
        int cnt = 0;
        BlockPos firstBase = null;
        for (BlockPos p : j.blocks) {
            if (p.getY() > minY) continue;
            if (firstBase == null) firstBase = p;
            x0 = Math.min(x0, p.getX()); x1 = Math.max(x1, p.getX());
            z0 = Math.min(z0, p.getZ()); z1 = Math.max(z1, p.getZ());
            sx += p.getX() + 0.5; sz += p.getZ() + 0.5; cnt++;
        }
        j.cx = sx / cnt;
        j.cz = sz / cnt;
        int baseW = Math.max(x1 - x0, z1 - z0) + 1;
        int height = maxY - minY + 1;
        j.topple = height >= 6 && height >= 3 * baseW;

        // направление заваливания: от игрока
        double tx, tz;
        if (c.hasPlayer()) {
            tx = j.cx - c.px();
            tz = j.cz - c.pz();
            double l = Math.hypot(tx, tz);
            if (l < 0.5) {
                double a = w.random.nextDouble() * Math.PI * 2;
                tx = Math.cos(a); tz = Math.sin(a);
            } else {
                tx /= l; tz /= l;
            }
        } else {
            double a = w.random.nextDouble() * Math.PI * 2;
            tx = Math.cos(a); tz = Math.sin(a);
        }
        j.tx = tx;
        j.tz = tz;

        // где земля под конструкцией
        int landY = minY;
        if (firstBase != null) {
            int lx = firstBase.getX(), lz = firstBase.getZ();
            for (int y = minY - 1; y >= Math.max(w.getBottomY(), minY - 320); y--) {
                BlockPos q = new BlockPos(lx, y, lz);
                if (!loaded(w, lx, lz)) break;
                BlockState s = w.getBlockState(q);
                if (!s.getCollisionShape(w, q).isEmpty() && !comp.contains(q.asLong())) {
                    landY = y + 1;
                    break;
                }
            }
        }
        j.landY = landY;

        // пыль в основании в момент начала обрушения
        addImpact(st, j.cx, minY, j.cz, comp.size() * 0.6);
        return j;
    }

    private static boolean fallable(BlockState s) {
        if (s.hasBlockEntity()) return false;
        Block b = s.getBlock();
        return !(b instanceof DoorBlock) && !(b instanceof BedBlock);
    }

    private static int fallTicks(double height) {
        double y = height, vy = 0;
        int t = 0;
        while (y > 0 && t < 2000) {
            vy = (vy - 0.04) * 0.98;
            y += vy;
            t++;
        }
        return Math.max(t, 1);
    }

    private static double[] velocity(ServerWorld w, Job j, BlockPos pos) {
        if (j.topple) {
            int span = Math.max(1, j.maxY - j.minY);
            double r = (pos.getY() - j.minY) / (double) span;
            int t = fallTicks(Math.max(1, pos.getY() - j.landY));
            double dist = r * (span + 1) * 0.85;
            double v = Math.min(2.5, dist * 0.02 / (1 - Math.pow(0.98, t)));
            double jitter = (w.random.nextDouble() - 0.5) * 0.06 * (1 + v);
            return new double[]{j.tx * v + jitter, j.tz * v + jitter};
        }
        double dx = pos.getX() + 0.5 - j.cx, dz = pos.getZ() + 0.5 - j.cz;
        double sx = Math.max(-0.15, Math.min(0.15, dx * 0.02)) + (w.random.nextDouble() - 0.5) * 0.06;
        double sz = Math.max(-0.15, Math.min(0.15, dz * 0.02)) + (w.random.nextDouble() - 0.5) * 0.06;
        return new double[]{sx, sz};
    }

    private static int runJob(ServerWorld w, WS st, Job j, int budget) {
        int n = 0;
        while (n < budget && j.idx < j.blocks.size()) {
            BlockPos pos = j.blocks.get(j.idx++);
            n++;
            BlockState s = w.getBlockState(pos);
            if (s.isAir()) continue;
            if (!fallable(s)) {
                w.breakBlock(pos, true);
                continue;
            }
            float hard = s.getHardness(w, pos);
            double mass = 1.0 + Math.min(Math.max(hard, 0f), 10f) * 0.4;
            FallingBlockEntity fb = FallingBlockEntity.spawnFromBlock(w, pos, s);
            double[] v = velocity(w, j, pos);
            fb.addVelocity(v[0], 0, v[1]);
            fb.setHurtEntities(2.0f, 40);
            st.debris.add(new Debris(fb, pos.getY(), mass, s));
        }
        return n;
    }

    // ----------------------------------------------------- приземление и дым

    private static void addImpact(WS st, double x, double y, double z, double e) {
        long key = BlockPos.asLong((int) Math.floor(x) >> 1, (int) Math.floor(y) >> 1, (int) Math.floor(z) >> 1);
        double[] a = st.impacts.get(key);
        if (a == null) st.impacts.put(key, new double[]{e, x, y, z});
        else a[0] += e;
    }

    private static BlockPos findPlaced(ServerWorld w, BlockPos p, Block b) {
        if (w.getBlockState(p).isOf(b)) return p;
        if (w.getBlockState(p.down()).isOf(b)) return p.down();
        if (w.getBlockState(p.up()).isOf(b)) return p.up();
        return null;
    }

    private static void trackDebris(ServerWorld w, WS st) {
        int shatterBudget = 150;
        Iterator<Debris> it = st.debris.iterator();
        while (it.hasNext()) {
            Debris d = it.next();
            if (!d.e.isRemoved()) continue;
            it.remove();

            double x = d.e.getX(), y = d.e.getY(), z = d.e.getZ();
            double h = d.startY - y;
            if (h < 2.0) continue;
            double energy = h * d.mass;
            addImpact(st, x, y, z, energy);

            // тяжёлый удар разбивает блок
            double chance = Math.min(0.9, Math.max(0.0, (energy - 40.0) / 250.0));
            if (chance > 0 && w.random.nextDouble() < chance) {
                BlockPos hit = findPlaced(w, BlockPos.ofFloored(x, y, z), d.state.getBlock());
                if (hit != null) {
                    if (shatterBudget-- > 0) w.breakBlock(hit, false);
                    else w.setBlockState(hit, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
    }

    private static void emitImpacts(ServerWorld w, WS st) {
        if (st.impacts.isEmpty()) return;
        int cells = 0;
        for (double[] a : st.impacts.values()) {
            if (cells++ >= MAX_CELLS_PER_TICK) break;
            double e = a[0] * smoke;
            if (e < 6) continue;
            double x = a[1], y = a[2] + 0.3, z = a[3];

            w.spawnParticles(ParticleTypes.POOF, x, y, z, (int) Math.min(40, 3 + e / 8), 0.6, 0.3, 0.6, 0.03);
            if (e >= 25) {
                w.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.5, z, (int) Math.min(60, e / 6), 0.8, 0.5, 0.8, 0.04);
            }
            if (e >= 90) {
                w.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y + 0.5, z, (int) Math.min(30, e / 30), 0.7, 0.2, 0.7, 0.02);
            }
            if (e >= 400) {
                w.spawnParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y + 1.0, z, (int) Math.min(20, e / 80), 0.8, 0.3, 0.8, 0.02);
            }
        }
        st.impacts.clear();
    }
}
